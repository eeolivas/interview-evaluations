'use strict';
angular.module('myApp').controller('QuestionsCtrl', function($state){});
