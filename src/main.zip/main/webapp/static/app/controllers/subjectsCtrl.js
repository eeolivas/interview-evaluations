'use strict';
angular.module('myApp').controller('SubjectsCtrl', function($state){});
