'use strict';
angular.module('myApp').controller('TraineesCtrl', function($state){});
