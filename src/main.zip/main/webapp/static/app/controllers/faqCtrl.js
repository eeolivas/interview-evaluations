'use strict';
angular.module('myApp').controller('FAQCtrl', function($state){});
