'use strict';
angular.module('myApp').controller('BatchCtrl', function($state){});
