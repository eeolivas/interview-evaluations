'use strict';
angular.module('myApp').controller('HomeCtrl', function($state){});
