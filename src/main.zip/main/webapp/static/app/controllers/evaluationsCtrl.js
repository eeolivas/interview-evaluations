'use strict';
angular.module('myApp').controller('EvaluationsCtrl', function($state){});
