'use strict';
angular.module('myApp').controller('TrainersCtrl', function($state){});
