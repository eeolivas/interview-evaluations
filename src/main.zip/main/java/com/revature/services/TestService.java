package com.revature.services;

public class TestService {
	
	/*
	public void breakBuild() {
		AtomicInteger aInt1 = new AtomicInteger(0);
		AtomicInteger aInt2 = new AtomicInteger(0);

		if (aInt1.equals(aInt2)) { }  // Noncompliant
	}
	*/
	
}
